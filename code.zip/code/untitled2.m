img = imread('/Users/delphine/Documents/211A/project/picture/2014_10_16/2014_10_16 06.51PM/494_g.png');
figure()
imagesc(img);
colormap(jet);